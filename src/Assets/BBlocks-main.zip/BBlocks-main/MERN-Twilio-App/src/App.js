import React, { Component } from 'react';
import './App.css';
import SMSForm from './SMSForm';

class App extends Component {

  render() {
    return (
      <div className="App">
        <SMSForm />
      </div>
    );
  }
}

export default App;
